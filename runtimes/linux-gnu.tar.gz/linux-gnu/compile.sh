#!/bin/bash
RUNTIME_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_SRC="$1"

# Set LD_LIBRARY_PATH specifically to use runtime libs FIRST
export LD_LIBRARY_PATH="$RUNTIME_DIR"

cd "$PROJECT_SRC" || exit 1
"$RUNTIME_DIR/bgdc" main.prg

