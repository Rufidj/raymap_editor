#!/bin/bash
RUNTIME_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$1"

export LD_LIBRARY_PATH="$RUNTIME_DIR"

echo "--- RUN WRAPPER ---"

cd "$PROJECT_ROOT" || exit 1
"$RUNTIME_DIR/bgdi" src/main.dcb

